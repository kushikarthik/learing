package com;

public class Callable {

}
