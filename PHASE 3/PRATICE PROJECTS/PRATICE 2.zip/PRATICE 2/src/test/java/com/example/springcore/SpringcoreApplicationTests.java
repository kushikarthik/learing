package com.example.springcore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringcoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
