package com.ss;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Phase3ProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(Phase3ProjectApplication.class, args);
	}

}
