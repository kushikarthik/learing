package com.ss.service;

public class MainAppService {

}
